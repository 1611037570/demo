1、template开发时减少过多的div嵌套。
0、使用自定义 Snowflake主题色类名，参考知识库开发文档中的主题色彩章节
1、对话全程请保持语言为中文
2、项目主题色是蓝色
3、vue文件使用setup语法糖，如果是./src/components/目录下的组件使用ts开发，其他组件使用js开发
4、组件使用./src/components/目录下的，如果没有使用elementplus的组件
4、样式使用 Tailwind CSS，在Tailwind实在不能实现的情况下，才使用style。
5、如果需要使用图标，名称使用 @iconify/vue 图标库，渲染使用SfIcon组件，已全局挂载直接使用，无需再判断是否存在
6、style 不要使用lang="scss"
7、UI需要有背景hover和文字hover效果，resume下的按钮不需要
8、如果使用到注释，导入和函数配置块的的注释移在代码上方，参数注释在右侧
9、组件导入和使用时，使用大驼峰命名法
10、样式和注释风格都是极简风
