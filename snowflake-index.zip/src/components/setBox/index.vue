<template>
  <div class="rounded-xl w-[450px] bg-sf-primary">
    <slot></slot>
  </div>
</template>

<script setup></script>

<style lang="scss" scoped></style>
