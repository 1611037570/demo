<template>
  <el-input v-model="modelValue" />
</template>

<script setup>
const modelValue = defineModel('modelValue')
</script>

<style scoped></style>
