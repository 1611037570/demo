const zhCN = {
  // 首页
  home: {},
}

export default zhCN
