export const default_data = {
  name: '',
  url: '',
  id: '',
}

export const list = [
  {
    name: 'boss直聘',
    url: 'https://www.zhipin.com/',
  },
  {
    name: '腾讯文档',
    url: 'https://docs.qq.com/desktop',
  },
  {
    name: '小红书',
    url: 'https://www.xiaohongshu.com/explore',
  },
  {
    name: 'github',
    url: 'https://github.com/',
  },

  {
    name: '稀土掘金',
    url: 'https://juejin.cn/',
  },
  {
    name: '考试宝',
    url: 'https://www.zaixiankaoshi.com/',
  },
  {
    name: '京东',
    url: 'https://www.jd.com/',
  },
  {
    name: '百度贴吧',
    url: 'https://tieba.baidu.com/',
  },
  {
    name: '百度翻译',
    url: 'https://fanyi.baidu.com/',
  },
  {
    name: '云顶之弈',
    url: 'https://lol.qq.com/tft/#/index',
  },
  {
    name: '攻略中心',
    url: 'https://101.qq.com/#/hero-rank-5v5',
  },

  {
    name: '哔哩哔哩',
    url: 'https://www.bilibili.com/',
  },
  {
    name: '爱奇艺',
    url: 'https://www.iqiyi.com/',
  },
  {
    name: '腾讯视频',
    url: 'https://v.qq.com/',
  },
  {
    name: '百度AI图片助手',
    url: 'https://image.baidu.com/useSearchStore/index?word=bdaitpzs%E7%99%BE%E5%BA%A6AI%E5%9B%BE%E7%89%87%E5%8A%A9%E6%89%8Bbdaitpzs',
  },
  {
    name: 'element-plus',
    url: 'https://element-plus.org/zh-CN/component/overview.html',
  },
]
