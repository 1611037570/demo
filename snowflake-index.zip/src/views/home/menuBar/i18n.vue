<script setup></script>

<template><div>i18n</div></template>

<style lang="scss" scoped></style>
