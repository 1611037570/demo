<template>
  <div
    class="bottom-2 border-blue-100/40 bg-blue-50/80 px-3 py-1 text-xs text-blue-400/70 shadow-sm backdrop-blur-sm hover:bg-blue-100/70 fixed left-1/2 z-10 flex -translate-x-1/2 items-center justify-center rounded-full border transition-all duration-300"
  >
    <span class="font-medium"> 2020-2025 XiaoYang</span>
    <span class="mx-1">•</span>
    <span class="text-xs">版权所有</span>
  </div>
</template>

<script setup>
// 固定年份范围显示
</script>
<!-- background-color:  -->
